/*
Proposito:Aplicación que permita almacenar en un ArrayList los datos de cualquier 
entidad (persona, cosa, lugar, …., etc).
Autores:
German Mejia - 202373276
Santiago Mafla - 202363125
Sebastian Bolaños - 202363165
Version:2.0
Fecha:03/09/2024
 */
package laboratorio1;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Laboratorio1 {
    ArrayList<Bugatti> arr = new ArrayList<>();
    Scanner sc = new Scanner (System.in);

    public void leerDatos() {
        Bugatti obj1 = new Bugatti();
        obj1.setVin();
        if (existe(obj1.getVin())) {
            JOptionPane.showMessageDialog(null, "Vehículo con el VIN ya existe :3");
        } else {
            obj1.setModelo();
            obj1.setColor();
            obj1.setPrecio();
            obj1.setVelocidadMax();
            obj1.setCaballosdeFuerza();
            arr.add(obj1);
        }
    }

    public boolean existe(int VinBuscar) {
        for (Bugatti bugat : arr) {
            if (bugat.getVin() == VinBuscar) return true;
        }
        return false;
    }

    public void verDatos() {
        StringBuilder listado = new StringBuilder("Listado de Bugattis:\n");
        for (Bugatti bugat : arr) {
            listado.append(bugat).append("\n");
                    System.out.println(bugat);
        }
    }
//CONSULTAR POR ATRIBUTOS Y LISTADO GENERAL
    public void ListadoGeneral(){
        if (arr.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
            } 
        else {
            System.out.println("Listado General de Bugattis:");
            for (Bugatti bugat : arr) {
                System.out.println(bugat);
                }
            }
    }
    
    public void consultarPorColor() {
        String color = JOptionPane.showInputDialog("Ingrese el color del vehículo:");
        boolean encontrado = false;

        for (Bugatti bugat : arr) {
            if (bugat.getColor().equals(color)) {
                System.out.println(bugat);
                encontrado = true;
            }
        }
        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No se encontraron vehículos con ese color.");
        }
    }
    
    public void consultarPorPrecio() {
        double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del vehículo:"));
        boolean encontrado = false;
        for (Bugatti bugat : arr) {
            if (bugat.getPrecio() == precio) {
                System.out.println(bugat);
                encontrado = true;
            }
        }
        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No se encontraron vehículos con ese precio.");
        }
    }
    
    public void consultarPorModelo() {
        int modelo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el modelo del vehículo:"));
        boolean encontrado = false;
        for (Bugatti bugat : arr) {
            if (bugat.getModelo()== modelo) {
                System.out.println(bugat);
                encontrado = true;
            }
        }
        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No se encontraron vehículos con esa velocidad máxima.");
        }
    }
    
    private void consultarPorVelocidadMax() {
    double velocidadMax = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la velocidad máxima del vehículo:"));
    boolean encontrado = false;

    for (Bugatti bugat : arr) {
        if (bugat.getVelocidadMax() == velocidadMax) {
            System.out.println(bugat);
            encontrado = true;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(null, "No se encontraron vehículos con esa velocidad máxima.");
    }
}
    
    public void consultarPorAtributo() {
        String[] opciones = {"Consultar por VIN","Consultar por Color", "Consultar por modelo", "Consultar por Precio", "Consultar por Velocidad Máxima","Cancelar"};
        int opc = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Consultar por Atributo",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
        switch (opc) {
            case 0:
                consul_x_vin(); break;
            case 1:
                consultarPorColor();
                break;
            case 2:
                consultarPorModelo();
                break;
            case 3:
                consultarPorPrecio(); 
                break;
            case 4:
                consultarPorVelocidadMax();
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "Consulta cancelada.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, intente de nuevo.");
        }
    }
        
    public void subMenuConsultas() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"1. Listado General","2. Consultar por atributos","Volver al Menú Principal"};
            int opc = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Consultas",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
            switch (opc) {
                case 0:ListadoGeneral();break;
                case 1:consultarPorAtributo(); break;
                case 2:volver = true; break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }
    public void consul_x_vin() {
        int vin = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el VIN del vehículo:"));
        boolean existe = false;
        for (Bugatti bugat : arr) {
            if (bugat.getVin() == vin) {
                System.out.println(bugat);
                existe = true;
                break;
            }
        }
        if (!existe) {
            JOptionPane.showMessageDialog(null, "VIN inexistente");
        }
    }
    
//GESTIONAR VEHICULOS    
    public void eliminarVehiculo() {
        int vin = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el VIN del vehículo a eliminar:"));
        boolean eliminado = false;
        for (int i = 0; i < arr.size(); i++) {
            if (arr.get(i).getVin() == vin) {
                arr.remove(i);
                JOptionPane.showMessageDialog(null, "Vehículo eliminado exitosamente.");
                eliminado = true;
                break;
            }
        }
        if (!eliminado) {
            JOptionPane.showMessageDialog(null, "VIN inexistente. No se pudo eliminar el vehículo.");
        }
    }
    
    public void modificarVehiculo() {
    int vin = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el VIN del vehículo a modificar:"));
    boolean encontrado = false;

    for (Bugatti bugat : arr) {
        if (bugat.getVin() == vin) {
            encontrado = true;

            String[] opciones = {"1. Modificar Modelo", "2. Modificar Color", "3. Modificar Precio", "4. Modificar Velocidad Máxima", "5. Modificar Caballos de Fuerza", "6. Cancelar"};
            int opc = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Modificar Vehículo",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);

            switch (opc) {
                case 0:
                    bugat.setModelo();
                    break;
                case 1:
                    bugat.setColor();
                    break;
                case 2:
                    bugat.setPrecio();
                    break;
                case 3:
                    bugat.setVelocidadMax();
                    break;
                case 4:
                    bugat.setCaballosdeFuerza();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "Modificación cancelada.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(null, "VIN inexistente. No se pudo modificar el vehículo.");
    } else {
        JOptionPane.showMessageDialog(null, "Vehículo modificado exitosamente.");
        }
    }
    
//ESTADISTICAS
    
    public void Estadisticas(){
         if (arr.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay vehículos registrados para mostrar estadísticas.");
            return;
        }
        double sumaVelocidadMax = 0;
        int sumaPrecio = 0;
        int totalVehiculos = arr.size();
        int[] distribucionColores = new int[4];
        
        for (Bugatti bugat : arr) {
            sumaVelocidadMax += bugat.getVelocidadMax();
            sumaPrecio += bugat.getPrecio();
            String color = bugat.getColor().toLowerCase();
            if (color.equals("rojo")) {
                distribucionColores[0]++;
            } else if (color.equals("azul")) {
                distribucionColores[1]++;
            } else if (color.equals("negro")) {
                distribucionColores[2]++;} 
             else {
                distribucionColores[3]++;
            }
        }

        double promedioVelocidadMax = sumaVelocidadMax / totalVehiculos;
        double promedioPrecio = sumaPrecio / totalVehiculos;

        String estadisticas = String.format("""
                                            Estadisticas de Bugattis:
                                            Promedio de velocidad maxima: %.2f km/h
                                            Promedio de precio: %f USD
                                            Distribucion de colores:
                                             - Rojo: %d
                                             - Azul: %d
                                             - Negro: %d
                                             - Otros: %d""",
                promedioVelocidadMax, promedioPrecio, distribucionColores[0], distribucionColores[1], distribucionColores[2],distribucionColores[3]);
        JOptionPane.showMessageDialog(null, estadisticas);
    }

//Definicion menus
    public void menu() {
        boolean salir = false;
        while (!salir) {
            String[] opciones = {
                    "1. Gestion de Vehiculos", "2. Listados","3. Estadisticas","4. Acerca de","5. Salir"};
            int opc = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Menú Principal",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
            switch (opc) {
                case 0: subMenuGestionVehiculos(); break;
                case 1: subMenuConsultas(); break;
                case 2: Estadisticas(); break;
                case 3: AcercaDe(); break;
                case 4: salir = true;
                    JOptionPane.showMessageDialog(null, "Saliendo del programa..."); break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }
    
    public void subMenuGestionVehiculos() {
        boolean volver = false;
        while (!volver) {
            String[] opciones = {"1. Ingresar Datos de Vehículo", "2. Ver Datos de Vehículos", "3. Modificar Vehiculo", "4. Eliminar Vehiculo", "5. Volver al Menú Principal"};
            int opc = JOptionPane.showOptionDialog(null, "Seleccione una opción", "Gestión de Vehículos",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opciones, opciones[0]);
            switch (opc) {
                case 0:
                    leerDatos();
                    break;
                case 1:
                    verDatos();
                    break;
                case 2: 
                    modificarVehiculo();
                    break ;
                case 3:
                    eliminarVehiculo();
                    break;
                case 4:
                    volver = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }
        
    public void AcercaDe(){
        JOptionPane.showMessageDialog(null, """
                                            1. German Mejia - 2023632762.
                                            2. Santiago Mafla - 202363125.
                                            3. Sebastian Bolaños - 202363165
                                            """, "Progamadores", 0);
    }


    public static void main(String[] args) {
        Laboratorio1 app = new Laboratorio1();
        app.menu();
    }
}