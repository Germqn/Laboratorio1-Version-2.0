/*
Proposito: Definicion de la clase Bugatti
Autores:
German Mejia - 202373276
Santiago Mafla
Sebastian Bolaños
Version:1.0
Fecha:31/08/2024
 */
package laboratorio1;

import javax.swing.JOptionPane;

public class Bugatti {
   int Vin, Precio , Modelo, VelocidadMax;
   String Color;
   double CaballosdeFuerza[];

   
   public void Bugatti(){
       Color = "-";
       Vin = Precio = Modelo = VelocidadMax = 0;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }
    
    public void setColor(){
        Color = JOptionPane.showInputDialog("Ingrese el color del vehiculo: ");
        
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public void setPrecio() {
        Precio = Integer.parseInt (JOptionPane.showInputDialog("Ingrese el precio del vehiculo"));
    }

    public int getModelo() {
        return Modelo;
    }

    public void setModelo(int Modelo) {
        this.Modelo = Modelo;
    }
    
    public void setModelo() {
        Modelo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el modelo del vehiculo : "));
    }

    public int getVelocidadMax() {
        return VelocidadMax;
    }

    public void setVelocidadMax(int VelocidadMax) {
        this.VelocidadMax = VelocidadMax;
    }
    
    public void setVelocidadMax() {
        VelocidadMax = Integer.parseInt(JOptionPane.showInputDialog("Ingresa la velocidad maxima del vehiculo: "));
    }

    public int getVin() {
        return Vin;
    }

    public void setVin(int Vin) {
        this.Vin = Vin;
    }
    
    public void setVin() {
        Vin = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el VIN del vehiculo: "));
    }

    public double[] getCaballosdeFuerza() {
        return CaballosdeFuerza;
    }

    public void setCaballosdeFuerza(double[] CaballosdeFuerza) {
        this.CaballosdeFuerza = CaballosdeFuerza;
    }
    
    public void setCaballosdeFuerza() {
        Double.parseDouble(JOptionPane.showInputDialog("Ingrese los caballos de fuerza del vehiculo: "));
    }

    @Override
    public String toString() {
        return "Bugatti{" + "El Vin del vehiculo es=" + Vin + ", El precio del vehiculo es=" + Precio 
                + ", El modelo del vehiculo es=" + Modelo + ", La VelocidadMax del vehiculo es=" + VelocidadMax 
                + ", El color del vehiculo es=" + Color 
                + ", Los Caballos de Fuerza del vehiculo son=" + CaballosdeFuerza + '}';
    }
    

}


